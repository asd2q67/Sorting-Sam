<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.2" name="Terrain - Ancient Ruins" tilewidth="32" tileheight="32" tilecount="537" columns="36" objectalignment="topleft">
 <image source="../Tilesets/Tileset-Terrain2.png" width="1152" height="448"/>
 <tile id="0"/>
 <tile id="1"/>
 <tile id="2"/>
 <tile id="3"/>
 <tile id="4"/>
 <tile id="5"/>
 <tile id="6"/>
 <tile id="7"/>
 <tile id="8"/>
 <tile id="9"/>
 <tile id="10"/>
 <tile id="11"/>
 <tile id="12"/>
 <tile id="13"/>
 <tile id="14"/>
 <tile id="15"/>
 <tile id="16"/>
 <tile id="17"/>
 <tile id="18"/>
 <tile id="19"/>
 <tile id="20"/>
 <tile id="21"/>
 <tile id="22"/>
 <tile id="23"/>
 <tile id="24"/>
 <tile id="25"/>
 <tile id="26"/>
 <tile id="27"/>
 <tile id="28"/>
 <tile id="29"/>
 <tile id="30"/>
 <tile id="31"/>
 <tile id="32"/>
 <tile id="33"/>
 <tile id="34"/>
 <tile id="35"/>
 <tile id="36"/>
 <tile id="37"/>
 <tile id="38"/>
 <tile id="39"/>
 <tile id="40"/>
 <tile id="41"/>
 <tile id="42"/>
 <tile id="43"/>
 <tile id="44"/>
 <tile id="45"/>
 <tile id="46"/>
 <tile id="47"/>
 <tile id="48"/>
 <tile id="49"/>
 <tile id="50"/>
 <tile id="51"/>
 <tile id="52"/>
 <tile id="53"/>
 <tile id="54"/>
 <tile id="55"/>
 <tile id="56"/>
 <tile id="57"/>
 <tile id="58"/>
 <tile id="59"/>
 <tile id="60"/>
 <tile id="61"/>
 <tile id="62"/>
 <tile id="63"/>
 <tile id="64"/>
 <tile id="65"/>
 <tile id="66"/>
 <tile id="67"/>
 <tile id="68"/>
 <tile id="69"/>
 <tile id="70"/>
 <tile id="71"/>
 <tile id="72"/>
 <tile id="73"/>
 <tile id="74"/>
 <tile id="75"/>
 <tile id="76"/>
 <tile id="77"/>
 <tile id="78"/>
 <tile id="79"/>
 <tile id="80"/>
 <tile id="81"/>
 <tile id="82"/>
 <tile id="83"/>
 <tile id="84"/>
 <tile id="85"/>
 <tile id="86"/>
 <tile id="87"/>
 <tile id="88"/>
 <tile id="89"/>
 <tile id="90"/>
 <tile id="91"/>
 <tile id="92" probability="10"/>
 <tile id="93"/>
 <tile id="94"/>
 <tile id="95"/>
 <tile id="96"/>
 <tile id="97" probability="3"/>
 <tile id="98"/>
 <tile id="99"/>
 <tile id="100"/>
 <tile id="101"/>
 <tile id="102"/>
 <tile id="103"/>
 <tile id="104"/>
 <tile id="105"/>
 <tile id="106"/>
 <tile id="107"/>
 <tile id="108"/>
 <tile id="109"/>
 <tile id="110"/>
 <tile id="111"/>
 <tile id="112"/>
 <tile id="113"/>
 <tile id="114"/>
 <tile id="115"/>
 <tile id="116"/>
 <tile id="117"/>
 <tile id="118"/>
 <tile id="119"/>
 <tile id="120"/>
 <tile id="121"/>
 <tile id="122"/>
 <tile id="123"/>
 <tile id="124"/>
 <tile id="125"/>
 <tile id="126"/>
 <tile id="127"/>
 <tile id="128"/>
 <tile id="129"/>
 <tile id="130"/>
 <tile id="131"/>
 <tile id="132"/>
 <tile id="133" probability="3"/>
 <tile id="134"/>
 <tile id="135"/>
 <tile id="136"/>
 <tile id="137"/>
 <tile id="138"/>
 <tile id="139"/>
 <tile id="140"/>
 <tile id="141"/>
 <tile id="142"/>
 <tile id="143"/>
 <tile id="144"/>
 <tile id="145"/>
 <tile id="146" probability="10"/>
 <tile id="147"/>
 <tile id="148"/>
 <tile id="149"/>
 <tile id="150"/>
 <tile id="151" probability="10"/>
 <tile id="152"/>
 <tile id="153"/>
 <tile id="154"/>
 <tile id="155"/>
 <tile id="156" probability="10"/>
 <tile id="157"/>
 <tile id="158"/>
 <tile id="159"/>
 <tile id="160"/>
 <tile id="161" probability="10"/>
 <tile id="162" probability="5"/>
 <tile id="163"/>
 <tile id="164"/>
 <tile id="165"/>
 <tile id="166" probability="5"/>
 <tile id="167"/>
 <tile id="168"/>
 <tile id="169" probability="3"/>
 <tile id="170"/>
 <tile id="171"/>
 <tile id="172" probability="10"/>
 <tile id="173"/>
 <tile id="174"/>
 <tile id="175"/>
 <tile id="176"/>
 <tile id="177" probability="10"/>
 <tile id="178"/>
 <tile id="179"/>
 <tile id="180"/>
 <tile id="181"/>
 <tile id="182"/>
 <tile id="183"/>
 <tile id="184"/>
 <tile id="185"/>
 <tile id="186"/>
 <tile id="187"/>
 <tile id="188"/>
 <tile id="189"/>
 <tile id="190"/>
 <tile id="191"/>
 <tile id="192"/>
 <tile id="193"/>
 <tile id="194"/>
 <tile id="195"/>
 <tile id="196"/>
 <tile id="197"/>
 <tile id="198" probability="5"/>
 <tile id="199" probability="5"/>
 <tile id="200" probability="5"/>
 <tile id="201" probability="5"/>
 <tile id="202" probability="5"/>
 <tile id="203"/>
 <tile id="204"/>
 <tile id="205" probability="3"/>
 <tile id="206"/>
 <tile id="207"/>
 <tile id="208"/>
 <tile id="209"/>
 <tile id="210"/>
 <tile id="211"/>
 <tile id="212"/>
 <tile id="213"/>
 <tile id="214"/>
 <tile id="215"/>
 <tile id="216"/>
 <tile id="217"/>
 <tile id="218"/>
 <tile id="219"/>
 <tile id="220"/>
 <tile id="221"/>
 <tile id="222"/>
 <tile id="223"/>
 <tile id="224"/>
 <tile id="225"/>
 <tile id="226"/>
 <tile id="227"/>
 <tile id="228"/>
 <tile id="229"/>
 <tile id="230"/>
 <tile id="231"/>
 <tile id="232"/>
 <tile id="233"/>
 <tile id="234" probability="5"/>
 <tile id="235" probability="5"/>
 <tile id="236" probability="5"/>
 <tile id="237" probability="5"/>
 <tile id="238" probability="5"/>
 <tile id="239"/>
 <tile id="240"/>
 <tile id="241"/>
 <tile id="242"/>
 <tile id="243"/>
 <tile id="244"/>
 <tile id="245"/>
 <tile id="246"/>
 <tile id="247"/>
 <tile id="248"/>
 <tile id="249"/>
 <tile id="250"/>
 <tile id="251"/>
 <tile id="252"/>
 <tile id="253"/>
 <tile id="254"/>
 <tile id="255"/>
 <tile id="256"/>
 <tile id="257"/>
 <tile id="258"/>
 <tile id="259"/>
 <tile id="260"/>
 <tile id="261"/>
 <tile id="262"/>
 <tile id="263"/>
 <tile id="264"/>
 <tile id="265"/>
 <tile id="266"/>
 <tile id="267"/>
 <tile id="268"/>
 <tile id="269"/>
 <tile id="270" probability="3"/>
 <tile id="271" probability="3"/>
 <tile id="272" probability="3"/>
 <tile id="273" probability="3"/>
 <tile id="274" probability="3"/>
 <tile id="275"/>
 <tile id="276"/>
 <tile id="277"/>
 <tile id="278"/>
 <tile id="279"/>
 <tile id="280"/>
 <tile id="281"/>
 <tile id="282"/>
 <tile id="283"/>
 <tile id="284"/>
 <tile id="285"/>
 <tile id="286"/>
 <tile id="287"/>
 <tile id="288"/>
 <tile id="289"/>
 <tile id="290"/>
 <tile id="291"/>
 <tile id="292"/>
 <tile id="293"/>
 <tile id="294"/>
 <tile id="295"/>
 <tile id="296"/>
 <tile id="297"/>
 <tile id="298"/>
 <tile id="299"/>
 <tile id="300"/>
 <tile id="301"/>
 <tile id="302"/>
 <tile id="303"/>
 <tile id="304"/>
 <tile id="305"/>
 <tile id="306"/>
 <tile id="307"/>
 <tile id="308"/>
 <tile id="309"/>
 <tile id="310"/>
 <tile id="311"/>
 <tile id="312"/>
 <tile id="313"/>
 <tile id="314"/>
 <tile id="315"/>
 <tile id="316"/>
 <tile id="317"/>
 <tile id="318"/>
 <tile id="319"/>
 <tile id="320"/>
 <tile id="321"/>
 <tile id="322"/>
 <tile id="323"/>
 <tile id="324"/>
 <tile id="325"/>
 <tile id="326" probability="0.5"/>
 <tile id="327"/>
 <tile id="328"/>
 <tile id="329"/>
 <tile id="330"/>
 <tile id="331" probability="0.5"/>
 <tile id="332"/>
 <tile id="333"/>
 <tile id="334"/>
 <tile id="335"/>
 <tile id="336"/>
 <tile id="337"/>
 <tile id="338"/>
 <tile id="339"/>
 <tile id="340"/>
 <tile id="341" probability="0.5"/>
 <tile id="342"/>
 <tile id="343"/>
 <tile id="344"/>
 <tile id="345"/>
 <tile id="346" probability="0.5"/>
 <tile id="347"/>
 <tile id="348"/>
 <tile id="349"/>
 <tile id="350"/>
 <tile id="351"/>
 <tile id="352"/>
 <tile id="353"/>
 <tile id="354"/>
 <tile id="355"/>
 <tile id="356"/>
 <tile id="357"/>
 <tile id="358"/>
 <tile id="359"/>
 <tile id="360"/>
 <tile id="361"/>
 <tile id="362"/>
 <tile id="363"/>
 <tile id="364"/>
 <tile id="365"/>
 <tile id="366"/>
 <tile id="367"/>
 <tile id="368"/>
 <tile id="369"/>
 <tile id="370"/>
 <tile id="371"/>
 <tile id="372"/>
 <tile id="373"/>
 <tile id="374"/>
 <tile id="375"/>
 <tile id="376"/>
 <tile id="377"/>
 <tile id="378"/>
 <tile id="379"/>
 <tile id="380"/>
 <tile id="381"/>
 <tile id="382"/>
 <tile id="383"/>
 <tile id="384"/>
 <tile id="385"/>
 <tile id="386"/>
 <tile id="387"/>
 <tile id="388"/>
 <tile id="389"/>
 <tile id="390"/>
 <tile id="391"/>
 <tile id="392"/>
 <tile id="393"/>
 <tile id="394"/>
 <tile id="395"/>
 <tile id="396"/>
 <tile id="397"/>
 <tile id="398"/>
 <tile id="399"/>
 <tile id="400"/>
 <tile id="401"/>
 <tile id="402"/>
 <tile id="403"/>
 <tile id="404"/>
 <tile id="405"/>
 <tile id="406"/>
 <tile id="407"/>
 <tile id="408"/>
 <tile id="409"/>
 <tile id="410"/>
 <tile id="411"/>
 <tile id="412"/>
 <tile id="413"/>
 <tile id="414"/>
 <tile id="415"/>
 <tile id="416"/>
 <tile id="417"/>
 <tile id="418"/>
 <tile id="419"/>
 <tile id="420"/>
 <tile id="421"/>
 <tile id="422"/>
 <tile id="423"/>
 <tile id="424" probability="0.5"/>
 <tile id="425"/>
 <tile id="426"/>
 <tile id="427"/>
 <tile id="428"/>
 <tile id="429" probability="0.5"/>
 <tile id="430"/>
 <tile id="431"/>
 <tile id="432"/>
 <tile id="433"/>
 <tile id="434"/>
 <tile id="435"/>
 <tile id="436"/>
 <tile id="437"/>
 <tile id="438"/>
 <tile id="439"/>
 <tile id="440"/>
 <tile id="441"/>
 <tile id="442"/>
 <tile id="443"/>
 <tile id="444" probability="0.5"/>
 <tile id="445"/>
 <tile id="446"/>
 <tile id="447"/>
 <tile id="448"/>
 <tile id="449"/>
 <tile id="450"/>
 <tile id="451"/>
 <tile id="452"/>
 <tile id="453"/>
 <tile id="454"/>
 <tile id="455"/>
 <tile id="456"/>
 <tile id="457"/>
 <tile id="458"/>
 <tile id="459"/>
 <tile id="460"/>
 <tile id="461"/>
 <tile id="462"/>
 <tile id="463"/>
 <tile id="464"/>
 <tile id="465"/>
 <tile id="466"/>
 <tile id="467"/>
 <tile id="468"/>
 <tile id="469"/>
 <tile id="470"/>
 <tile id="471"/>
 <tile id="472"/>
 <tile id="473"/>
 <tile id="474"/>
 <tile id="475"/>
 <tile id="476"/>
 <tile id="477"/>
 <tile id="478"/>
 <tile id="479"/>
 <tile id="480"/>
 <tile id="481"/>
 <tile id="482"/>
 <tile id="483"/>
 <tile id="484"/>
 <tile id="485"/>
 <tile id="486"/>
 <tile id="487"/>
 <tile id="488"/>
 <tile id="489"/>
 <tile id="490"/>
 <tile id="491"/>
 <tile id="492"/>
 <tile id="493"/>
 <tile id="494"/>
 <tile id="495"/>
 <tile id="496"/>
 <tile id="497"/>
 <tile id="498"/>
 <tile id="499"/>
 <tile id="500"/>
 <tile id="501"/>
 <tile id="502"/>
 <tile id="503"/>
 <tile id="545"/>
 <tile id="550"/>
 <tile id="555"/>
 <tile id="560"/>
 <tile id="576"/>
 <tile id="777"/>
 <tile id="824"/>
 <tile id="858"/>
 <tile id="871"/>
 <tile id="918"/>
 <tile id="1093"/>
 <tile id="1756"/>
 <tile id="1761"/>
 <tile id="1793"/>
 <tile id="1798"/>
 <tile id="1802"/>
 <tile id="1803"/>
 <tile id="1807"/>
 <tile id="1808"/>
 <tile id="1839"/>
 <tile id="1840"/>
 <tile id="1844"/>
 <tile id="1845"/>
 <tile id="1985"/>
 <tile id="1990"/>
 <tile id="1995"/>
 <tile id="2028"/>
 <tile id="2033"/>
 <tile id="2074"/>
 <tile id="2075"/>
 <tile id="2079"/>
 <tile id="2080"/>
 <tile id="2090"/>
 <wangsets>
  <wangset name="stone ground" type="corner" tile="-1">
   <wangcolor name="" color="#ff0000" tile="-1" probability="1"/>
   <wangtile tileid="306" wangid="0,1,0,0,0,1,0,0"/>
   <wangtile tileid="307" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="308" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="309" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="310" wangid="0,0,0,1,0,0,0,1"/>
   <wangtile tileid="342" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="343" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="344" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="345" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="346" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="347" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="348" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="349" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="350" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="351" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="352" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="353" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="354" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="355" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="356" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="357" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="358" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="378" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="379" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="380" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="381" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="382" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="383" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="384" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="385" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="386" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="387" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="388" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="389" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="390" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="391" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="392" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="393" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="394" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="414" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="415" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="416" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="417" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="418" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="421" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="424" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="425" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="426" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="427" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="428" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="429" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="430" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="451" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="452" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="453" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="455" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="456" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="457" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="458" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="459" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="491" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="492" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="493" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="494" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="495" wangid="0,1,0,1,0,1,0,1"/>
  </wangset>
  <wangset name="grass_" type="corner" tile="-1">
   <wangcolor name="" color="#ff0000" tile="-1" probability="1"/>
   <wangtile tileid="18" wangid="0,1,0,0,0,1,0,0"/>
   <wangtile tileid="19" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="20" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="21" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="22" wangid="0,0,0,1,0,0,0,1"/>
   <wangtile tileid="54" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="55" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="56" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="57" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="58" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="90" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="91" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="92" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="93" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="94" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="126" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="127" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="128" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="129" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="130" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="162" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="163" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="164" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="165" wangid="0,0,0,0,0,0,0,1"/>
   <wangtile tileid="166" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="198" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="199" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="200" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="201" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="202" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="234" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="235" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="236" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="237" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="238" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="270" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="271" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="272" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="273" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="274" wangid="0,1,0,1,0,1,0,1"/>
  </wangset>
 </wangsets>
</tileset>
